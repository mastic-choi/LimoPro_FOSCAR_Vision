#!/usr/bin/env bash
# Ubuntu + NVIDIA RTX: 환경 설치 후 학습. 끊겨도 같은 명령을 다시 실행하면 이어서 한다.
#   bash run_train.sh                 (기본: hybridnets tln_large yolop yolopv2 순서)
#   bash run_train.sh --models hybridnets
set -e
cd "$(dirname "$0")"
# .bashrc가 올리는 ROS noetic(Python 3.8)과 CUDA 12.1 경로는 학습에 필요 없다. PYTHONPATH는 venv 패키지보다 앞에 오므로 뺀다
unset PYTHONPATH LD_LIBRARY_PATH
# 8GB GPU에서 메모리 조각화를 줄인다 (tln_large batch 8 예약 6.1GB -> 5.3GB)
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
TORCH_INDEX="${TORCH_INDEX:-https://download.pytorch.org/whl/cu128}"
py_ok() { "$1" -c 'import sys; sys.exit(not (3, 10) <= sys.version_info[:2] <= (3, 12))' >/dev/null 2>&1; }
if [ ! -f .venv/.ready ]; then
  PY=""
  # 시스템 python3가 3.8인 PC가 있어 버전까지 확인한다. 없으면 Anaconda의 3.12를 쓴다
  for c in python3.10 python3.11 python3.12 python3 "$HOME/anaconda3/bin/python3.12"; do
    if py_ok "$c"; then PY="$c"; break; fi
  done
  [ -n "$PY" ] || { echo "Python 3.10~3.12가 없습니다. 설치 후 다시 실행하세요."; exit 1; }
  "$PY" -m venv .venv || { echo "venv 실패: sudo apt install python3-venv"; exit 1; }
  .venv/bin/python -m pip install -U pip
  .venv/bin/python -m pip install torch==2.11.0 torchvision==0.26.0 --index-url "$TORCH_INDEX"
  .venv/bin/python -m pip install -r requirements_rtx.txt
  touch .venv/.ready
fi
# 절전 방지. 권한이 없어 실패하는 환경(SSH 등)에서는 그냥 실행
if command -v systemd-inhibit >/dev/null 2>&1 && systemd-inhibit --what=sleep:idle --who=LimoPro --why=check true >/dev/null 2>&1; then
  exec systemd-inhibit --what=sleep:idle --who=LimoPro --why=training .venv/bin/python scripts/run_train.py "$@"
fi
exec .venv/bin/python scripts/run_train.py "$@"
