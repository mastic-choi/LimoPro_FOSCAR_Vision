#!/usr/bin/env python3
"""학습이 끝난 4개 모델과 앙상블을 test에서 평가한다. 학습이 끝난 뒤에 실행한다(GPU 사용).

  .venv/bin/python scripts/eval_ensemble.py

앙상블 규칙은 1차와 같다: da = 멤버 확률 평균 >= 0.5, ll = 과반 투표, 최종 da = da | ll. 멤버는 best_da.pt를 쓴다.
출력 <out>/: eval.json(그룹별 IoU, precision, recall), 몽타주 jpg (파랑 = 맞춤, 빨강 = 정답 밖까지 칠함, 노랑 = 놓침)
"""
import argparse
import csv
import json
import os
import sys

import cv2
import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import train_seg as T

MODELS = ("hybridnets", "tln_large", "yolop", "yolopv2")
WIDE = 0.40  # 옆 차로까지 칠한 것으로 의심하는 da 면적 (test 정답에는 이 이상이 없음)


class Score:
    def __init__(self):
        self.c = {"da": np.zeros(3, np.int64), "ll": np.zeros(3, np.int64)}  # tp, fp, fn
        self.wide = self.over = self.n = 0

    def add(self, da, ll, gda, gll):
        for k, p, t in (("da", da, gda), ("ll", ll, gll)):
            self.c[k] += np.array([(p & t).sum(), (p & ~t).sum(), (~p & t).sum()])
        self.n += 1
        self.wide += int(da.mean() >= WIDE)
        self.over += int(da.sum() >= 1.3 * max(gda.sum(), 1))

    def result(self):
        out = {"n": self.n, "pred_da_wide": self.wide, "pred_da_over130": self.over}
        for k, (tp, fp, fn) in self.c.items():
            out[f"{k}_iou"] = round(float(tp / max(tp + fp + fn, 1)), 4)
            out[f"{k}_precision"] = round(float(tp / max(tp + fp, 1)), 4)
            out[f"{k}_recall"] = round(float(tp / max(tp + fn, 1)), 4)
        return out


def prep(img, rgb, norm):
    img = cv2.copyMakeBorder(img, T.PAD, T.PAD, 0, 0, cv2.BORDER_CONSTANT, value=(114, 114, 114))
    if rgb:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    x = img.astype(np.float32) / 255.0
    if norm:
        x = (x - np.array([0.485, 0.456, 0.406], np.float32)) / np.array([0.229, 0.224, 0.225], np.float32)
    return torch.from_numpy(x.transpose(2, 0, 1).copy())


def load(m, name, run_dir, weight):
    model, rgb, norm, fwd, _ = T.ADAPTERS[name](m)
    w = os.path.join(run_dir, weight)
    if name == "yolopv2":
        model = T.load_yolopv2_trainable(w, m.device)
    else:
        model.load_state_dict(torch.load(w, map_location="cpu"))
    return model.to(m.device).eval(), rgb, norm, fwd


def tile(img, da, gda, ll, label):
    v = img.astype(np.float32)
    for mask, color in ((da & gda, (255, 80, 0)), (da & ~gda, (0, 0, 255)), (~da & gda, (0, 255, 255))):
        v[mask] = v[mask] * .5 + np.array(color) * .5
    v[ll] = (255, 255, 255)
    v = cv2.resize(v.astype(np.uint8), (320, 180))
    cv2.rectangle(v, (0, 0), (319, 20), (0, 0, 0), -1)
    cv2.putText(v, label, (4, 15), cv2.FONT_HERSHEY_SIMPLEX, .45, (255, 255, 255), 1, cv2.LINE_AA)
    return v


def montage(items, path, cols=4):
    ts = list(items)
    while len(ts) % cols:
        ts.append(np.zeros_like(ts[0]))
    cv2.imwrite(path, np.vstack([np.hstack(ts[i:i + cols]) for i in range(0, len(ts), cols)]), [cv2.IMWRITE_JPEG_QUALITY, 88])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=os.path.join(ROOT, "dataset", "ego_v2_ys_split"))
    ap.add_argument("--train-dir", default=os.path.join(ROOT, "outputs", "train"))
    ap.add_argument("--suffix", default="_v2")
    ap.add_argument("--out", default=os.path.join(ROOT, "outputs", "eval"))
    ap.add_argument("--batch", type=int, default=4)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    import make_model_compare_gif as m
    with open(os.path.join(args.data, "manifest.csv"), encoding="utf-8") as f:
        man = {r["frame"]: r for r in csv.DictReader(f) if r["split"] == "test" and r["use"] == "1"}
    names = sorted(man)

    def groups(r):
        g = ["all", "curve" if r["curve"] == "1" else "straight"]
        p = "v1" if r["split_old"] == "test" else "new"
        g += [p, f"{p}_{'curve' if r['curve'] == '1' else 'straight'}"]
        if p == "new":
            g += ["new_hard" if r["hard"] == "1" else "new_easy", f"new_{r['decision']}"]
        return g

    runs = {n: os.path.join(args.train_dir, f"{n}{args.suffix}_seed0") for n in MODELS}
    members = {n: load(m, n, runs[n], "best_da.pt") for n in MODELS}
    limiter = m.GpuDutyLimiter()
    scores = {}
    add = lambda who, g, *a: scores.setdefault(who, {}).setdefault(g, Score()).add(*a)
    per_frame = []
    for k in range(0, len(names), args.batch):
        chunk = names[k:k + args.batch]
        imgs = [cv2.imread(os.path.join(args.data, "test", "images", f"{n}.png")) for n in chunk]
        gda = [cv2.imread(os.path.join(args.data, "test", "da_masks", f"{n}.png"), 0) > 0 for n in chunk]
        gll = [cv2.imread(os.path.join(args.data, "test", "ll_masks", f"{n}.png"), 0) > 0 for n in chunk]
        pda, pll = {}, {}
        with limiter, torch.no_grad():
            for name, (model, rgb, norm, fwd) in members.items():
                x = torch.stack([prep(im, rgb, norm) for im in imgs]).to(m.device)
                a, b = fwd(model, x)
                pda[name], pll[name] = T.crop(a).float().cpu().numpy(), T.crop(b).float().cpu().numpy()
        da_all, ll_all = np.stack([pda[n] for n in MODELS]), np.stack([pll[n] for n in MODELS])
        ens_ll = (ll_all >= .5).sum(0) >= len(MODELS) // 2 + 1
        ens_da = (da_all.mean(0) >= .5) | ens_ll
        for j, n in enumerate(chunk):
            for g in groups(man[n]):
                add("ensemble", g, ens_da[j], ens_ll[j], gda[j], gll[j])
                for name in MODELS:
                    add(name, g, pda[name][j] >= .5, pll[name][j] >= .5, gda[j], gll[j])
            u = (ens_da[j] | gda[j]).sum()
            iou = float((ens_da[j] & gda[j]).sum() / max(u, 1))
            lu = (ens_ll[j] | gll[j]).sum()
            per_frame.append(dict(frame=n, group="v1" if man[n]["split_old"] == "test" else "new", curve=man[n]["curve"], hard=man[n]["hard"],
                                  decision=man[n]["decision"], da_iou=round(iou, 4), ll_iou=round(float((ens_ll[j] & gll[j]).sum() / max(lu, 1)), 4)))
    res = {w: {g: s.result() for g, s in gs.items()} for w, gs in scores.items()}

    # test.json과 같은 값이 나오는지 교차 확인 (best_da, 같은 임계값)
    check = {}
    for name in MODELS:
        with open(os.path.join(runs[name], "test.json"), encoding="utf-8") as f:
            t = json.load(f)["test"]["all"]
        check[name] = {"da_diff": round(abs(t["da_iou"] - res[name]["all"]["da_iou"]), 4), "ll_diff": round(abs(t["ll_iou"] - res[name]["all"]["ll_iou"]), 4)}
    with open(os.path.join(args.out, "eval.json"), "w", encoding="utf-8") as f:
        json.dump({"models": MODELS, "check_vs_test_json": check, "result": res, "per_frame": per_frame}, f, ensure_ascii=False, indent=1)

    # 몽타주: 앙상블 기준 나쁜 장면 / 보통 장면
    def render(rows):
        for r in rows:
            n = r["frame"]
            img = cv2.imread(os.path.join(args.data, "test", "images", f"{n}.png"))
            with torch.no_grad():
                ps = []
                for name, (model, rgb, norm, fwd) in members.items():
                    a, b = fwd(model, prep(img, rgb, norm)[None].to(m.device))
                    ps.append((T.crop(a).float().cpu().numpy()[0], T.crop(b).float().cpu().numpy()[0]))
            ll = sum(p[1] >= .5 for p in ps) >= len(MODELS) // 2 + 1
            da = (np.mean([p[0] for p in ps], 0) >= .5) | ll
            gda = cv2.imread(os.path.join(args.data, "test", "da_masks", f"{n}.png"), 0) > 0
            yield tile(img, da, gda, ll, f"{n[6:]} da {r['da_iou']:.2f} ll {r['ll_iou']:.2f} {'curve' if r['curve'] == '1' else 'straight'} {r['decision']}")

    for grp in ("v1", "new"):
        rows = sorted((r for r in per_frame if r["group"] == grp), key=lambda r: r["da_iou"])
        montage(render(rows[:12]), os.path.join(args.out, f"worst_{grp}.jpg"))
        mid = [rows[i] for i in np.linspace(len(rows) * .3, len(rows) * .7, 12).astype(int)]
        montage(render(mid), os.path.join(args.out, f"typical_{grp}.jpg"))
    print(json.dumps({w: {g: [v[g]["da_iou"], v[g]["ll_iou"]] for g in ("all", "v1", "v1_curve", "new", "new_curve", "new_hard")} for w, v in res.items()}, indent=1))
    print("test.json 대비 차이:", check)


if __name__ == "__main__":
    main()
