#!/usr/bin/env python3
"""검수 노트북 결과(<...>_review 폴더)를 학습 데이터셋에 합쳐 새 폴더로 만든다. 원본 데이터셋은 건드리지 않는다.

  .venv/bin/python scripts/merge_review.py dataset/ego_v2 <review 폴더> dataset/ego_v2_ys --reviewer 최윤성

- trust, corrected만 train에 추가한다. discard는 review.csv에만 남아 있으므로 넣지 않는다.
- 다음이면 아무것도 만들지 않고 중단한다: 파일 누락/형식 오류, val/test 구간 침범, 기존 프레임과 겹침.
- 프레임 번호 ±3 안에 dHash 거리 6 미만인 프레임이 이미 있으면 manifest에 dup=1, use=0으로 남기고 복사하지 않는다.
- manifest의 bend, slope, curve는 build_train_dataset.py와 같은 식으로 계산한다.
"""
import argparse
import csv
import os
import shutil
import sys

import cv2
import numpy as np

SUBDIRS = ("images", "da_masks", "ll_masks")
EXCLUDE = ((1970, 2329), (4270, 4959))  # val/test 구간 + 앞뒤 30프레임 (make_finetuned_pseudo_labels.py --exclude와 같음)
DUP_WINDOW, DUP_DHASH = 3, 6
KEEP = ("trust", "corrected")


def dhash(img, size=8):
    g = cv2.resize(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), (size + 1, size), interpolation=cv2.INTER_AREA)
    return (g[:, 1:] > g[:, :-1]).flatten()


def bend(da):
    h, w = da.shape
    ys = np.flatnonzero(da.any(1))
    if ys.size < 20:
        return 0.0, 0.0
    cx = np.array([np.flatnonzero(da[y]).mean() for y in ys])
    a2, a1, _ = np.polyfit((ys - ys.max()) / h, (cx - w / 2) / w, 2)
    return abs(a2), abs(a1)


def num(frame):
    return int(frame.split("_")[1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", help="기존 데이터셋 폴더 (manifest.csv 포함)")
    ap.add_argument("review", help="검수 결과 폴더 (review.csv, images/, da_masks/, ll_masks/)")
    ap.add_argument("out", help="새로 만들 데이터셋 폴더 (이미 있으면 중단)")
    ap.add_argument("--reviewer", required=True, help="manifest의 reviewer 열에 쓸 이름")
    args = ap.parse_args()
    if os.path.exists(args.out):
        sys.exit(f"이미 있습니다: {args.out}")

    with open(os.path.join(args.base, "manifest.csv"), encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fields, base = reader.fieldnames, list(reader)
    known = {r["frame"] for r in base}
    with open(os.path.join(args.review, "review.csv"), encoding="utf-8") as f:
        review = [r for r in csv.DictReader(f) if r["decision"] in KEEP]

    errors, new = [], {}
    for r in sorted(review, key=lambda r: num(r["frame"])):
        s = r["frame"]
        if s in known or s in new:
            errors.append(f"{s}: 기존 프레임 또는 review.csv 안에서 겹침")
        if any(a <= num(s) <= b for a, b in EXCLUDE):
            errors.append(f"{s}: val/test 구간 침범")
        im, da, ll = (cv2.imread(os.path.join(args.review, d, f"{s}.png"), -1) for d in SUBDIRS)
        if im is None or da is None or ll is None:
            errors.append(f"{s}: 파일 누락 또는 읽기 실패")
            continue
        if im.shape != (360, 640, 3) or da.shape != (360, 640) or ll.shape != (360, 640):
            errors.append(f"{s}: 크기 오류 {im.shape} {da.shape} {ll.shape}")
        if not set(np.unique(da)) | set(np.unique(ll)) <= {0, 255}:
            errors.append(f"{s}: 마스크 값이 0/255가 아님")
        new[s] = (r, im, da > 0)
    if errors:
        print("\n".join(errors[:30]))
        sys.exit(f"오류 {len(errors)}건: 아무것도 만들지 않았습니다.")

    kept = {}  # 프레임 번호 -> dHash (train에 들어 있는 프레임)
    for r in base:
        if r["split"] == "train" and r["use"] == "1":
            kept[num(r["frame"])] = dhash(cv2.imread(os.path.join(args.base, "train", "images", r["frame"] + ".png")))

    rows, copy = [], []
    for s, (r, im, da) in new.items():
        n, h = num(s), dhash(im)
        dup = any(n + k in kept and int((kept[n + k] != h).sum()) < DUP_DHASH for k in range(-DUP_WINDOW, DUP_WINDOW + 1))
        if not dup:
            kept[n] = h
            copy.append(s)
        a2, a1 = bend(da)
        hard = int(not (r["source"] == "OK (unreviewed)" and r["decision"] == "trust"))
        rows.append({"frame": s, "split": "train", "curve": int(a2 >= 1.0 or a1 >= 0.4), "bend": round(a2, 3), "slope": round(a1, 3),
                     "dup": int(dup), "use": int(not dup), "source": r["source"], "decision": r["decision"],
                     "reviewer": args.reviewer, "hard": hard})

    tmp = args.out + ".tmp"
    if os.path.exists(tmp):
        sys.exit(f"이전 작업의 임시 폴더가 남아 있습니다: {tmp}")
    shutil.copytree(args.base, tmp)
    for s in copy:
        for d in SUBDIRS:
            shutil.copy2(os.path.join(args.review, d, f"{s}.png"), os.path.join(tmp, "train", d, f"{s}.png"))
    with open(os.path.join(tmp, "manifest.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(base)
        w.writerows(rows)
    os.replace(tmp, args.out)  # 끝까지 성공했을 때만 완성된 이름이 생김
    print(f"추가 {len(copy)}장, 중복 제외 {len(rows) - len(copy)}장 -> {args.out}")


if __name__ == "__main__":
    main()
