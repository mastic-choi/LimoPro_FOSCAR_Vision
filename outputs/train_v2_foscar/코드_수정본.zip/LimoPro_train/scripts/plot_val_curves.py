#!/usr/bin/env python3
"""모델별 val IoU 곡선 그림. usage: plot_val_curves.py [--train-dir outputs/train] [--out outputs/eval/val_curves.png]"""
import argparse
import csv
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SERIES = (("hybridnets", "HybridNets", "#2a78d6"), ("tln_large", "TwinLiteNet+", "#eb6834"), ("yolop", "YOLOP", "#1baf7a"), ("yolopv2", "YOLOPv2", "#eda100"))
SURFACE, INK, MUTED, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e6e5e1"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train-dir", default=os.path.join(ROOT, "outputs", "train"))
    ap.add_argument("--suffix", default="_v2")
    ap.add_argument("--out", default=os.path.join(ROOT, "outputs", "eval", "val_curves.png"))
    args = ap.parse_args()
    # Noto CJK는 한 파일에 여러 언어가 묶여 있어 matplotlib에는 JP 이름으로 잡힌다. 한글 글자도 들어 있다
    plt.rcParams.update({"font.family": "Noto Sans CJK JP", "font.size": 11, "axes.unicode_minus": False})
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.6), dpi=150, facecolor=SURFACE)
    panels = (("val_da_iou", "주행가능영역(da) val IoU"), ("val_ll_iou", "차선(ll) val IoU"))
    data = {}
    for key, _, _ in SERIES:
        d = os.path.join(args.train_dir, f"{key}{args.suffix}_seed0")
        with open(os.path.join(d, "log.csv"), encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        with open(os.path.join(d, "test.json"), encoding="utf-8") as f:
            data[key] = (rows, json.load(f)["best_val"]["epoch"])
    for ax, (col, title) in zip(axes, panels):
        ax.set_facecolor(SURFACE)
        for key, label, color in SERIES:
            rows, best = data[key]
            x = [int(r["epoch"]) for r in rows]
            y = [float(r[col]) for r in rows]
            ax.plot(x, y, color=color, lw=2, solid_joinstyle="round", solid_capstyle="round", label=label, zorder=3)
            ax.plot(best, y[best - 1], "o", ms=8, mfc=color, mec=SURFACE, mew=2, zorder=4)
        ys = [float(r[col]) for key, _, _ in SERIES for r in data[key][0][1:]]
        lo, hi = min(ys) - .006, max(ys) + .006
        ax.set_ylim(lo, hi)
        ax.set_xlim(0.5, 49)
        ax.set_xticks(range(0, 41, 10))
        # 선 끝 직접 라벨: 글자는 먹색, 서로 겹치지 않게 간격을 벌림
        ends = sorted((float(data[key][0][-1][col]), len(data[key][0]), label) for key, label, _ in SERIES)
        gap, prev = (hi - lo) * .07, -1
        for y, ep, label in ends:
            pos = max(y, prev + gap)
            prev = pos
            ax.annotate(label, xy=(ep, y), xytext=(41.5, pos), va="center", color=INK, fontsize=9.5,
                        arrowprops=dict(arrowstyle="-", color=GRID, lw=1, shrinkA=1, shrinkB=2))
        ax.set_xlabel("epoch", color=MUTED)
        ax.set_title(title, loc="left", color=INK, fontsize=12, pad=10)
        ax.grid(axis="y", color=GRID, lw=1)
        ax.set_axisbelow(True)
        ax.tick_params(colors=MUTED, length=0)
        for s in ("top", "right", "left"):
            ax.spines[s].set_visible(False)
        ax.spines["bottom"].set_color(GRID)
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=4, frameon=False, labelcolor=INK, bbox_to_anchor=(.5, -.01))
    fig.text(.995, .955, "점 = 모델별 최고 점수 epoch (첫 epoch는 축 범위에서 제외)", ha="right", color=MUTED, fontsize=9.5)
    fig.tight_layout(rect=(0, .07, 1, 1))
    fig.savefig(args.out, facecolor=SURFACE)
    print(args.out)


if __name__ == "__main__":
    main()
