#!/usr/bin/env python3
"""2차 모델 결과 몽타주. 학습에 쓰지 않은 test 프레임만 쓴다. eval_ensemble.py를 먼저 실행해야 한다(eval.json 사용).

  .venv/bin/python scripts/make_result_montage.py

출력 <out>/:
  result_compare.jpg  행 = 프레임, 열 = 원본 | 정답 | 모델 4개 | 앙상블. 프레임은 앙상블 da 점수의 분위수로 고른다.
  result_driving.gif  test 구간 주행. 원본 | 앙상블 | 모델 4개
색: 파랑 = da, 빨강 = ll (저장소의 다른 몽타주와 같음).
"""
import argparse
import csv
import json
import os

import cv2
import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont

import eval_ensemble as E

ROOT = E.ROOT
FONT = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
NAMES = {"hybridnets": "HybridNets", "tln_large": "TwinLiteNet+ L", "yolop": "YOLOP", "yolopv2": "YOLOPv2", "ensemble": "4개 앙상블"}


def overlay(img, da, ll, size):
    v = img.astype(np.float32)
    v[da] = v[da] * .55 + np.array([255, 80, 0]) * .45
    v[ll] = (0, 0, 255)
    return cv2.resize(v.astype(np.uint8), size, interpolation=cv2.INTER_AREA)


def iou(a, b):
    return float((a & b).sum() / max((a | b).sum(), 1))


def predict(members, img, device):
    """-> {이름: (da, ll)}. 앙상블 규칙은 eval_ensemble.py, 1차와 같다."""
    out, das, lls = {}, [], []
    with torch.no_grad():
        for name, (model, rgb, norm, fwd) in members.items():
            a, b = fwd(model, E.prep(img, rgb, norm)[None].to(device))
            a, b = E.T.crop(a).float().cpu().numpy()[0], E.T.crop(b).float().cpu().numpy()[0]
            out[name] = (a >= .5, b >= .5)
            das.append(a)
            lls.append(b)
    ll = (np.stack(lls) >= .5).sum(0) >= len(lls) // 2 + 1
    out["ensemble"] = ((np.mean(das, 0) >= .5) | ll, ll)
    return out


def put(draw, xy, text, font, fill=(255, 255, 255)):
    draw.text(xy, text, font=font, fill=fill)


def pick_rows(per_frame):
    """분위수로 고른다. 같은 프레임이 두 번 뽑히면 다음 순위로 넘어간다."""
    used, rows = set(), []

    def take(label, cond, q):
        fs = sorted((r for r in per_frame if cond(r)), key=lambda r: r["da_iou"])
        for r in fs[int(len(fs) * q):] + fs[:int(len(fs) * q)][::-1]:
            if r["frame"] not in used:
                used.add(r["frame"])
                rows.append((label, r))
                return

    old, new = (lambda r: r["group"] == "v1"), (lambda r: r["group"] == "new")
    curve = lambda r: r["curve"] == "1"
    take("기존 test · 직진 · 중앙값", lambda r: old(r) and not curve(r), .5)
    take("기존 test · 커브 · 중앙값", lambda r: old(r) and curve(r), .5)
    take("기존 test · 커브 · 하위 10%", lambda r: old(r) and curve(r), .1)
    take("추가 test · 직진 · 중앙값", lambda r: new(r) and not curve(r), .5)
    take("추가 test · 커브 · 중앙값", lambda r: new(r) and curve(r), .5)
    take("추가 test · 커브 · 하위 10%", lambda r: new(r) and curve(r), .1)
    take("추가 test · 사람이 고친 라벨 · 중앙값", lambda r: new(r) and r["decision"] == "corrected", .5)
    take("추가 test · 사람이 고친 라벨 · 하위 10%", lambda r: new(r) and r["decision"] == "corrected", .1)
    take("기존 test · 가장 낮은 점수", old, 0)
    take("추가 test · 가장 낮은 점수", new, 0)
    return rows


def compare(args, members, device, per_frame):
    tw, th, strip, head = 256, 144, 24, 62
    cols = ["원본", "정답"] + [NAMES[n] for n in E.MODELS] + [NAMES["ensemble"]]
    rows = pick_rows(per_frame)
    canvas = Image.new("RGB", (tw * len(cols), head + (th + strip) * len(rows)), (18, 18, 18))
    draw = ImageDraw.Draw(canvas)
    f_title, f_col, f_row = ImageFont.truetype(FONT, 18), ImageFont.truetype(FONT, 16), ImageFont.truetype(FONT, 14)
    put(draw, (8, 4), "LimoPro 2차 학습 결과 (학습에 쓰지 않은 test 프레임)   파랑 = da, 빨강 = ll, 칸 아래 숫자 = 그 프레임의 IoU", f_title)
    for c, name in enumerate(cols):
        put(draw, (c * tw + 8, 36), name, f_col)
    for i, (label, r) in enumerate(rows):
        n = r["frame"]
        d = os.path.join(args.data, "test")
        img = cv2.imread(os.path.join(d, "images", f"{n}.png"))
        gda = cv2.imread(os.path.join(d, "da_masks", f"{n}.png"), 0) > 0
        gll = cv2.imread(os.path.join(d, "ll_masks", f"{n}.png"), 0) > 0
        p = predict(members, img, device)
        y = head + i * (th + strip)
        draw.rectangle((0, y, canvas.width, y + strip), fill=(45, 45, 45))
        put(draw, (8, y + 2), f"{label}   frame {n[6:]}", f_row)
        tiles = [cv2.resize(img, (tw, th), interpolation=cv2.INTER_AREA), overlay(img, gda, gll, (tw, th))]
        tiles += [overlay(img, *p[k], (tw, th)) for k in (*E.MODELS, "ensemble")]
        for c, t in enumerate(tiles):
            canvas.paste(Image.fromarray(cv2.cvtColor(t, cv2.COLOR_BGR2RGB)), (c * tw, y + strip))
            if c >= 2:
                k = (*E.MODELS, "ensemble")[c - 2]
                x0, y0 = c * tw, y + strip + th - 20
                draw.rectangle((x0, y0, x0 + 132, y0 + 20), fill=(0, 0, 0))
                put(draw, (x0 + 5, y0 + 1), f"da {iou(p[k][0], gda):.2f}  ll {iou(p[k][1], gll):.2f}", f_row)
    path = os.path.join(args.out, "result_compare.jpg")
    canvas.save(path, quality=90)
    print(path, canvas.size, [(label, r["frame"][6:], r["da_iou"]) for label, r in rows])


def driving(args, members, device, per_frame):
    w, h, band = 320, 180, 24
    order = ["원본", "ensemble", "hybridnets", "tln_large", "yolop", "yolopv2"]
    new = sorted(r["frame"] for r in per_frame if r["group"] == "new")
    old = sorted(r["frame"] for r in per_frame if r["group"] == "v1")
    seq = [(n, "추가 test") for n in new[::args.stride]] + [(n, "기존 test") for n in old[::args.stride]]
    f_lab, f_foot = ImageFont.truetype(FONT, 15), ImageFont.truetype(FONT, 14)
    frames = []
    limiter = None
    import make_model_compare_gif as m
    limiter = m.GpuDutyLimiter()
    for n, grp in seq:
        img = cv2.imread(os.path.join(args.data, "test", "images", f"{n}.png"))
        with limiter:
            p = predict(members, img, device)
        canvas = Image.new("RGB", (w * 3, (h + band) * 2 + band), (18, 18, 18))
        draw = ImageDraw.Draw(canvas)
        for i, key in enumerate(order):
            t = cv2.resize(img, (w, h), interpolation=cv2.INTER_AREA) if key == "원본" else overlay(img, *p[key], (w, h))
            x, y = (i % 3) * w, (i // 3) * (h + band)
            put(draw, (x + 6, y + 2), NAMES.get(key, key), f_lab)
            canvas.paste(Image.fromarray(cv2.cvtColor(t, cv2.COLOR_BGR2RGB)), (x, y + band))
        put(draw, (6, canvas.height - band + 2), f"{grp}  frame {n[6:]}   파랑 = da, 빨강 = ll   라벨이 있는 프레임만 이어 붙여 장면이 끊길 수 있음", f_foot)
        frames.append(canvas.quantize(colors=128, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE))
    path = os.path.join(args.out, "result_driving.gif")
    frames[0].save(path, save_all=True, append_images=frames[1:], duration=int(1000 / args.fps), loop=0, optimize=False)
    print(path, f"{len(frames)}장, {len(frames) / args.fps:.0f}초, {os.path.getsize(path) / 1e6:.1f}MB")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=os.path.join(ROOT, "dataset", "ego_v2_ys_split"))
    ap.add_argument("--train-dir", default=os.path.join(ROOT, "outputs", "train"))
    ap.add_argument("--suffix", default="_v2")
    ap.add_argument("--eval", default=os.path.join(ROOT, "outputs", "eval", "eval.json"))
    ap.add_argument("--out", default=os.path.join(ROOT, "outputs", "montages"))
    ap.add_argument("--stride", type=int, default=3, help="GIF에서 test 프레임 간격")
    ap.add_argument("--fps", type=float, default=5)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    import make_model_compare_gif as m
    with open(args.eval, encoding="utf-8") as f:
        per_frame = json.load(f)["per_frame"]
    with open(os.path.join(args.data, "manifest.csv"), encoding="utf-8") as f:
        assert {r["frame"] for r in csv.DictReader(f) if r["split"] == "test" and r["use"] == "1"} == {r["frame"] for r in per_frame}, "eval.json과 test가 다름"
    members = {n: E.load(m, n, os.path.join(args.train_dir, f"{n}{args.suffix}_seed0"), "best_da.pt") for n in E.MODELS}
    compare(args, members, m.device, per_frame)
    driving(args, members, m.device, per_frame)


if __name__ == "__main__":
    main()
