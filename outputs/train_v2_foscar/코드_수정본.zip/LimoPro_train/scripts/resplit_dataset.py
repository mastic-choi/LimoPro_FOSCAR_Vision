#!/usr/bin/env python3
"""train 일부를 새 val/test 시간 구간으로 옮겨 새 데이터셋을 만든다. 원본 데이터셋은 건드리지 않는다.

  .venv/bin/python scripts/resplit_dataset.py dataset/ego_v2_ys dataset/ego_v2_ys_split \\
      --test-blocks 1610 1781 3352 3496 5671 5823 --val-blocks 10 121 3786 3929 7863 8059

- 연속 프레임은 서로 거의 같아서 무작위가 아니라 시간 구간 단위로만 나눈다.
- 기존 val/test는 그대로 둔다(1차 점수와 비교하기 위해). manifest의 split_old로 구분한다.
- 새 구간 앞뒤 --buffer 프레임 안의 train 프레임은 정답 유출을 막으려고 학습에서 뺀다(split=drop).
- 새 구간에서 da가 --max-da 이상인 프레임은 옆 차로까지 칠했을 수 있어 평가에서 뺀다. test 정답은 내 차로 기준이다.
"""
import argparse
import csv
import os
import shutil
import sys

import cv2

SUBDIRS = ("images", "da_masks", "ll_masks")


def num(frame):
    return int(frame.split("_")[1])


def pairs(flat):
    if len(flat) % 2:
        sys.exit("구간은 시작 끝 쌍으로 적어야 합니다")
    return list(zip(flat[::2], flat[1::2]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("out")
    ap.add_argument("--test-blocks", type=int, nargs="+", required=True)
    ap.add_argument("--val-blocks", type=int, nargs="+", required=True)
    ap.add_argument("--buffer", type=int, default=30)
    ap.add_argument("--max-da", type=float, default=0.40)
    args = ap.parse_args()
    if os.path.exists(args.out) or os.path.exists(args.out + ".tmp"):
        sys.exit(f"이미 있습니다: {args.out}")
    te, va = pairs(args.test_blocks), pairs(args.val_blocks)

    with open(os.path.join(args.base, "manifest.csv"), encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fields, rows = list(reader.fieldnames), list(reader)
    inside = lambda n, blocks, pad=0: any(a - pad <= n <= b + pad for a, b in blocks)
    held_old = [num(r["frame"]) for r in rows if r["use"] == "1" and r["split"] in ("val", "test")]
    if any(inside(n, te + va, args.buffer) for n in held_old):
        sys.exit("새 구간(+버퍼)이 기존 val/test 프레임과 겹칩니다")

    moves = []
    for r in rows:
        r["split_old"], r["drop"] = r["split"], ""
        if r["use"] != "1" or r["split"] != "train":
            continue
        n = num(r["frame"])
        new = "test" if inside(n, te) else "val" if inside(n, va) else None
        if new:
            da = cv2.imread(os.path.join(args.base, "train", "da_masks", r["frame"] + ".png"), 0)
            if (da > 0).mean() >= args.max_da:
                r["split"], r["use"], r["drop"] = "drop", "0", "wide_da"
            else:
                r["split"] = new
        elif inside(n, te + va, args.buffer):
            r["split"], r["use"], r["drop"] = "drop", "0", "buffer"
    for r in rows:
        if r["use"] == "1":
            moves.append((r["split_old"], r["split"], r["frame"]))

    # 유출 검사: train 프레임은 모든 val/test 프레임에서 buffer보다 멀어야 함 (기존 구간 포함)
    held = sorted(num(r["frame"]) for r in rows if r["use"] == "1" and r["split"] in ("val", "test"))
    leak = [r["frame"] for r in rows if r["use"] == "1" and r["split"] == "train" and any(abs(num(r["frame"]) - h) <= args.buffer for h in held)]
    if leak:
        sys.exit(f"train 프레임이 val/test와 너무 가깝습니다: {leak[:20]} (총 {len(leak)}장)")

    tmp = args.out + ".tmp"
    for s in ("train", "val", "test"):
        for d in SUBDIRS:
            os.makedirs(os.path.join(tmp, s, d))
    for old, new, frame in moves:
        for d in SUBDIRS:
            shutil.copy2(os.path.join(args.base, old, d, frame + ".png"), os.path.join(tmp, new, d, frame + ".png"))
    with open(os.path.join(tmp, "manifest.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields + ["split_old", "drop"])
        w.writeheader()
        w.writerows(rows)
    os.replace(tmp, args.out)
    count = lambda s: sum(r["use"] == "1" and r["split"] == s for r in rows)
    print(f"train {count('train')} / val {count('val')} / test {count('test')}, "
          f"제외 buffer {sum(r['drop'] == 'buffer' for r in rows)}, wide_da {sum(r['drop'] == 'wide_da' for r in rows)} -> {args.out}")


if __name__ == "__main__":
    main()
